library(fda)
sapply(dir("~/documents/fda/R", full.name=TRUE), source)