function putbifd(bifdobj, bifdParobj)
%  Replace the bivariate fd parameter

bifdParobj.fdobj = fdobj;